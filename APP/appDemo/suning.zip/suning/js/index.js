
window.onload=function(){
    document.getElementById('top_search').addEventListener('tap', function() {
        //打开关于页面
        mui.openWindow({
          url: 'search.html', 
          id:'top_search'
        });
      });





}
